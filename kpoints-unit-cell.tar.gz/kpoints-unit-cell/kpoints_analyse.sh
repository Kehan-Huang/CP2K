#!/bin/bash

kpoints="3 4 5 6 7 8 9 10 11 12 13 14 15"

input_file=cp2k.inp
output_file=log.out
plot_file=kpoints_data.ssv
number_of_atom=4.0
hatree_to_ev=27.2114

rel_cutoff=60

echo "# Grid kpoints vs total energy" > $plot_file
echo "# Date: $(date)" >> $plot_file
echo "# PWD: $PWD" >> $plot_file
#echo "# REL_CUTOFF = $rel_cutoff" >> $plot_file
echo -n "# KPOINTS | Total Energy per Atom (eV)" >> $plot_file
printf "\n" >> $plot_file
grid_header=false
for ii in $kpoints ; do
    work_dir=kpoints_${ii}
    total_energy=$(grep -e '^[ \t]*Total energy' $work_dir/$output_file | awk '{print $3}')
    total_energy_per_atom=`echo "$total_energy * $hatree_to_ev / $number_of_atom" | bc -l`
    ngrids=$(grep -e '^[ \t]*QS| Number of grid levels:' $work_dir/$output_file | \
             awk '{print $6}')
    if $grid_header ; then
        for ((igrid=1; igrid <= $ngrids; igrid++)) ; do
            printf " | NG on grid %d" $igrid >> $plot_file
        done
        grid_header=false
    fi
    printf "%10.0f  %15.10f" $ii $total_energy_per_atom >> $plot_file
#    for ((igrid=1; igrid <= $ngrids; igrid++)) ; do
#        grid=$(grep -e '^[ \t]*count for grid' $work_dir/$output_file | \
#               awk -v igrid=$igrid '(NR == igrid){print $5}')
#        printf "  %6d" $grid >> $plot_file
#    done
    printf "\n" >> $plot_file
done
